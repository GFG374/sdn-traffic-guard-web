# SDN Ubuntu部分文件

此文件夹包含需要在Ubuntu虚拟机中运行的SDN相关文件。

## 文件说明

1. **sdn_topology.py** - Mininet拓扑创建脚本
   - 支持环形拓扑和树形拓扑
   - 用于创建SDN网络环境

2. **simple_switch_13.py** - RYU控制器应用
   - 基于OpenFlow 1.3的简单交换机控制器
   - 实现基本的二层交换功能

3. **SDN_SETUP_GUIDE.md** - 完整的环境搭建指南
   - 包含Ubuntu环境准备步骤
   - Mininet和RYU的安装配置
   - 网络拓扑创建和测试流程

## 使用方法

### 在Ubuntu虚拟机中：

1. 启动RYU控制器：
   ```bash
   ryu-manager simple_switch_13.py
   ```

2. 创建网络拓扑：
   ```bash
   sudo python3 sdn_topology.py
   ```

3. 在Mininet CLI中测试：
   ```bash
   > pingall
   > net
   > dump
   ```

## 注意事项

- 确保Ubuntu已安装：Mininet、Open vSwitch、RYU控制器
- 修改sdn_topology.py中的控制器IP为Windows主机IP
- 保持Windows后端服务运行状态